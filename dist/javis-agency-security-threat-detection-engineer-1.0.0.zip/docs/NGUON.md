# Nguồn của agent `agency-security-threat-detection-engineer`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/security/security-threat-detection-engineer.md](https://github.com/msitarzewski/agency-agents/blob/main/security/security-threat-detection-engineer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho SenOS (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, SenOS báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
