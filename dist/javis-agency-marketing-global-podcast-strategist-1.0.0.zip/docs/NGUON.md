# Nguồn của agent `agency-marketing-global-podcast-strategist`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/marketing/marketing-global-podcast-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/marketing/marketing-global-podcast-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho SenOS (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, SenOS báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
