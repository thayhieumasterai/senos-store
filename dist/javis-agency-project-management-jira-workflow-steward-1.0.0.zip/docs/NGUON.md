# Nguồn của agent `agency-project-management-jira-workflow-steward`

Một agent lẻ của gói `javis.agency-agents`, lấy từ [msitarzewski/agency-agents/project-management/project-management-jira-workflow-steward.md](https://github.com/msitarzewski/agency-agents/blob/main/project-management/project-management-jira-workflow-steward.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho SenOS (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, SenOS báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
